import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, ArrowRight, Menu, Linkedin, Mail, Phone, User, Briefcase, Award } from 'lucide-react'
import Link from "next/link"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function LandingPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/90 shadow-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src="/images/fp-logo.png" alt="Francisco Peña Logo" className="w-8 h-8 object-contain" />
            <span className="text-xl font-bold text-blue-600">Francisco Pena</span>
          </div>

          <nav className="hidden md:flex items-center space-x-6">
            <Link href="#inicio" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Inicio
            </Link>
            <Link href="#perfil" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Perfil
            </Link>
            <Link href="#operacion-catalogo" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Operación & Catálogo
            </Link>
            <Link href="#analisis-automatizacion" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Análisis & Automatización
            </Link>
            <Link href="#contacto" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Contacto
            </Link>
          </nav>

          <div className="flex items-center space-x-4">
            <Link href="https://www.linkedin.com/in/franciscopena" target="_blank" rel="noopener noreferrer">
              <Button size="sm" className="bg-yellow-500 hover:bg-yellow-600 text-black">
                LinkedIn
                <Linkedin className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Button variant="ghost" size="sm" className="md:hidden">
              <Menu className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section
          id="inicio"
          className="w-full py-12 md:py-24 lg:py-32 xl:py-48 bg-gradient-to-br from-blue-50 to-yellow-50"
        >
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <Badge variant="secondary" className="w-fit bg-yellow-100 text-yellow-800">
                    🚀Especialista en eCommerce y Operación MercadoLibre
                  </Badge>
                  <h1 className="text-2xl font-bold tracking-tighter sm:text-4xl xl:text-5xl/none text-blue-900">
                    Soy Francisco Pena, profesional con más de 5 años potenciando ventas digitales
                  </h1>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    Especialista en eCommerce y operación de MercadoLibre para el sector construcción y pinturería.
                    Trabajo con la automatización de procesos y estrategias de pricing. Mi enfoque combina la eficiencia
                    operativa con una mirada comercial, ayudando a destacarse en MercadoLibre.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button size="lg" className="h-12 px-8 bg-yellow-500 hover:bg-yellow-600 text-black">
                    Descargar CV
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    className="h-12 px-8 border-blue-600 text-blue-600 hover:bg-blue-50 bg-transparent"
                  >
                    Ver Portafolio
                  </Button>
                </div>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Check className="h-4 w-4 text-green-500" />
                    <span>Gestión eCommerce</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Check className="h-4 w-4 text-green-500" />
                    <span>Logística</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Check className="h-4 w-4 text-green-500" />
                    <span>Estrategia de catálogo</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <div className="w-full max-w-[300px] aspect-square bg-gradient-to-r from-blue-600 to-blue-800 rounded-full flex items-center justify-center overflow-hidden border-4 border-yellow-500">
                  <User className="h-48 w-48 text-white" />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Acerca de mí Section */}
        <section id="perfil" className="w-full py-12 md:py-24 lg:py-32 bg-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                  🧠 Acerca de mí
                </Badge>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-blue-900">Resumen personal</h2>
              </div>
            </div>
            <div className="mx-auto max-w-3xl py-12 space-y-6 text-lg">
              <p className="text-muted-foreground">
                Soy vendedor especializado en el rubro de la construcción y pinturería, con más de 5 años de experiencia
                comercializando productos tanto en el canal tradicional como en plataformas digitales como MercadoLibre.
              </p>
              <p className="text-muted-foreground">
                Me destaco por entender las necesidades del profesional de obra, constructoras, pintores y talleres
                automotor, ofreciendo soluciones concretas y seguimiento postventa.
              </p>
              <p className="text-muted-foreground">
                Además, gestioné estrategias de precios, publicaciones y logística en plataformas de eCommerce,
                potenciando la presencia de marca y generando ventas sostenidas.
              </p>
              <p className="text-muted-foreground">
                Busco integrarme a una empresa con foco en calidad, servicio y crecimiento, donde pueda aportar mi
                experiencia comercial y seguir desarrollándome.
              </p>
            </div>
          </div>
        </section>

        {/* Operación & Catálogo Section */}
        <div id="operacion-catalogo">
          {/* Grid de especialidades */}
          <section className="w-full py-12 md:py-24 lg:py-32 bg-white">
            <div className="container px-4 md:px-6">
              <div className="flex flex-col items-center justify-center space-y-4 text-center">
                <div className="space-y-2">
                  <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                    🛠️ Especialidades
                  </Badge>
                  <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-blue-900">
                    Mis especialidades en eCommerce
                  </h2>
                </div>
              </div>
              <div className="mx-auto grid max-w-7xl items-center gap-4 py-12 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                <Card className="border-2 hover:border-yellow-300 transition-colors">
                  <CardHeader className="bg-blue-50 pb-2">
                    <CardTitle className="text-blue-900 text-sm">🛒 Publicaciones que venden</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <p className="text-muted-foreground text-sm">
                      Optimización de catálogo: títulos, palabras clave, imágenes y descripciones pensadas para
                      convertir.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-2 hover:border-yellow-300 transition-colors">
                  <CardHeader className="bg-blue-50 pb-2">
                    <CardTitle className="text-blue-900 text-sm">📦 Logística FULL & FLEX</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <p className="text-muted-foreground text-sm">
                      Carga y gestión de stock en CD de MercadoLibre. Coordinación de envíos FLEX en AMBA con eficiencia
                      operativa.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-2 hover:border-yellow-300 transition-colors">
                  <CardHeader className="bg-blue-50 pb-2">
                    <CardTitle className="text-blue-900 text-sm">🎯 Contenido que convierte (Clips + Ads)</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <p className="text-muted-foreground text-sm">
                      Desarrollo de piezas visuales y textos comerciales orientados a captar atención y generar acción.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-2 hover:border-yellow-300 transition-colors">
                  <CardHeader className="bg-blue-50 pb-2">
                    <CardTitle className="text-blue-900 text-sm">📊 Toma de decisiones con datos (KPIs)</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <p className="text-muted-foreground text-sm">
                      Monitoreo de ventas, posicionamiento y performance con herramientas de análisis integradas.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-2 hover:border-yellow-300 transition-colors">
                  <CardHeader className="bg-blue-50 pb-2">
                    <CardTitle className="text-blue-900 text-sm">🙌 Gestión postventa MercadoLibre</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <p className="text-muted-foreground text-sm">
                      Atención integral, resolución de reclamos y cuidado de la reputación del canal. Exclusiones
                      estratégicas.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-2 hover:border-yellow-300 transition-colors">
                  <CardHeader className="bg-blue-50 pb-2">
                    <CardTitle className="text-blue-900 text-sm">
                      🧩 Integración con sistemas de gestión (ERPs)
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <p className="text-muted-foreground text-sm">
                      Experiencia con plataformas de gestión conectadas a ecommerce. Adaptación ágil y técnica.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-2 hover:border-yellow-300 transition-colors">
                  <CardHeader className="bg-blue-50 pb-2">
                    <CardTitle className="text-blue-900 text-sm">🧠 Análisis de mercado y competencia</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <p className="text-muted-foreground text-sm">
                      Herramientas de desglose de precios y performance. Benchmarking para toma de decisiones rentable.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-2 hover:border-yellow-300 transition-colors">
                  <CardHeader className="bg-blue-50 pb-2">
                    <CardTitle className="text-blue-900 text-sm">🗂️ Catalogación técnica profesional</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <p className="text-muted-foreground text-sm">
                      Carga masiva optimizada, estructura por categorías, análisis de producto y detección de gaps.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-2 hover:border-yellow-300 transition-colors">
                  <CardHeader className="bg-blue-50 pb-2">
                    <CardTitle className="text-blue-900 text-sm">🤖 Automatización de procesos y atención</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <p className="text-muted-foreground text-sm">
                      Respuestas inteligentes integradas a MercadoLibre. Fichas técnicas accesibles y árboles de
                      decisión que mejoran conversión.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </section>

          {/* Conocimiento experto del catálogo técnico Section */}
          <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
            <div className="container px-4 md:px-6">
              <div className="flex flex-col items-center justify-center space-y-4 text-center">
                <div className="space-y-2">
                  <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                    📚 Conocimiento Técnico
                  </Badge>
                  <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-blue-900">
                    Conocimiento experto del catálogo técnico
                  </h2>
                </div>
              </div>
              <div className="mx-auto max-w-5xl py-12">
                <div className="flex justify-center items-center gap-8 mb-8 flex-wrap">
                  <img src="/images/logo-alba.png" alt="ALBA Logo" className="h-16 object-contain" />
                  <img src="/images/logo-venier.png" alt="VENIER Logo" className="h-16 object-contain" />
                  <img src="/images/logo-sika.png" alt="SIKA Logo" className="h-16 object-contain" />
                </div>
                <ul className="space-y-4 text-lg text-muted-foreground">
                  <li className="flex items-start space-x-3">
                    <Check className="h-6 w-6 text-yellow-500 flex-shrink-0 mt-1" />
                    <span>Identificación de productos según presentación comercial y rendimiento por m²</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Check className="h-6 w-6 text-yellow-500 flex-shrink-0 mt-1" />
                    <span>Dominio de las compatibilidades de productos</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Check className="h-6 w-6 text-yellow-500 flex-shrink-0 mt-1" />
                    <span>
                      Distinción entre usos profesionales y de hogar, adaptando la carga según el público objetivo
                    </span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Check className="h-6 w-6 text-yellow-500 flex-shrink-0 mt-1" />
                    <span>
                      Análisis de equivalencias entre marcas líderes, ampliando la oferta sin perder coherencia técnica
                      ni calidad percibida
                    </span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Check className="h-6 w-6 text-yellow-500 flex-shrink-0 mt-1" />
                    <span>
                      Traducción de fichas técnicas complejas en contenidos claros, SEO-optimizado y orientado a la
                      conversión
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </section>
        </div>

        {/* Experiencia Section */}
        <section id="experiencia" className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                  <Briefcase className="h-4 w-4 mr-1" /> Trayectoria
                </Badge>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-blue-900">
                  Mi experiencia profesional
                </h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Más de 5 años de experiencia en ventas técnicas y asesoramiento especializado
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-5xl py-12 space-y-8">
              <div className="flex flex-col md:flex-row gap-6 items-start border-l-4 border-yellow-500 pl-6 py-2">
                <div className="md:w-1/3">
                  <h3 className="text-xl font-bold text-blue-900">E-Commerce Manager</h3>
                  <p className="text-yellow-600 font-medium">Pinturerías Migliore · 2020 – Presente</p>
                </div>
                <div className="md:w-2/3 space-y-4">
                  <p className="text-muted-foreground">
                    Gestión integral de la operación en MercadoLibre: publicación, pricing, posicionamiento, logística
                    FULL/FLEX y atención postventa.
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-start space-x-2">
                      <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-muted-foreground">
                        Diseño de estrategias comerciales omnicanal para productos técnicos de construcción y automotor.
                      </span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-muted-foreground">
                        Optimización de catálogo técnico, automatización de respuestas frecuentes y desarrollo de piezas
                        publicitarias.
                      </span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-muted-foreground">
                        Posicionamiento de la marca entre el Top 3 del rubro a nivel ecommerce.
                      </span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-muted-foreground">
                        Desarrollo de herramienta interna de cotización dinámica (uso interno, alta adopción).
                      </span>
                    </li>
                  </ul>
                </div>
              </div>

              <div className="flex flex-col md:flex-row gap-6 items-start border-l-4 border-yellow-500 pl-6 py-2">
                <div className="md:w-1/3">
                  <h3 className="text-xl font-bold text-blue-900">Asistente de eCommerce</h3>
                  <p className="text-yellow-600 font-medium">MountainFunnel · 2018 – 2020</p>
                </div>
                <div className="md:w-2/3 space-y-4">
                  <p className="text-muted-foreground">
                    Administración operativa de tienda en MercadoLibre y soporte en la estrategia comercial digital para
                    productos de construcción.
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-start space-x-2">
                      <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-muted-foreground">
                        Optimización de publicaciones, estructura de categorías y análisis de pricing frente a
                        competencia.
                      </span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-muted-foreground">
                        Implementación de sistema de seguimiento postventa y gestión de reputación.
                      </span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-muted-foreground">
                        Integración básica con plataformas de gestión y automatización de tareas repetitivas.
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Habilidades Expandidas */}
        <section id="analisis-automatizacion" className="w-full py-12 md:py-24 lg:py-32 bg-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                  <Award className="h-4 w-4 mr-1" /> Competencias
                </Badge>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-blue-900">Mis habilidades clave</h2>
              </div>
            </div>
            <div className="mx-auto max-w-5xl py-12">
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger className="text-left">
                    <div className="flex items-center space-x-4">
                      <Check className="h-6 w-6 text-yellow-500 flex-shrink-0" />
                      <h3 className="text-lg font-bold text-blue-900">
                        Gestión estratégica de publicaciones y precios en eCommerce
                      </h3>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-muted-foreground mt-2">
                      Optimización integral de listings en MercadoLibre: fotografía, descripciones, SEO, categorización
                      y arquitectura de catálogo. Diseño de estrategias de pricing y promociones basadas en
                      estacionalidad, márgenes y análisis competitivo.
                    </p>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-2">
                  <AccordionTrigger className="text-left">
                    <div className="flex items-center space-x-4">
                      <Check className="h-6 w-6 text-yellow-500 flex-shrink-0" />
                      <h3 className="text-lg font-bold text-blue-900">
                        Conocimiento profundo en productos de obra, automotor y hogar
                      </h3>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-muted-foreground mt-2">
                      Especialización técnica en pinturas, revestimientos, impermeabilizantes y productos
                      complementarios. Comprensión de necesidades de cliente profesional, obra y retail.
                    </p>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-3">
                  <AccordionTrigger className="text-left">
                    <div className="flex items-center space-x-4">
                      <Check className="h-6 w-6 text-yellow-500 flex-shrink-0" />
                      <h3 className="text-lg font-bold text-blue-900">
                        Seguimiento postventa y fidelización de clientes
                      </h3>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-muted-foreground mt-2">
                      Gestión personalizada de postventa con foco en resolución ágil, asesoramiento técnico y retención.
                      Implementación de sistemas de seguimiento y campañas de recompra orientadas a satisfacción y
                      reputación.
                    </p>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-4">
                  <AccordionTrigger className="text-left">
                    <div className="flex items-center space-x-4">
                      <Check className="h-6 w-6 text-yellow-500 flex-shrink-0" />
                      <h3 className="text-lg font-bold text-blue-900">
                        Enfoque en logística y performance en eCommerce
                      </h3>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <p className="text-muted-foreground mt-2">
                      Administración completa de procesos logísticos en MercadoLibre: desde la publicación hasta la
                      entrega final. Dominio de envíos FULL, FLEX y tercerizados. Diseño de estrategias de stock,
                      catálogo y precios para mejorar conversión, tiempo de entrega y rentabilidad.
                    </p>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
          </div>
        </section>

        {/* Rentabilidad y P&L Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                  📊 Análisis Financiero
                </Badge>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-blue-900">
                  Especialista en Rentabilidad y P&L
                </h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Dominio avanzado en análisis de rentabilidad con herramientas especializadas
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-5xl py-12">
              <div className="flex justify-center">
                <Card className="border-2 hover:border-yellow-300 transition-colors max-w-2xl w-full">
                  <CardHeader className="bg-blue-50 pb-4">
                    <CardTitle className="text-blue-900 flex items-center gap-2">
                      📈 Análisis P&L - 🔧 Herramientas Especializadas
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <ul className="space-y-3 text-muted-foreground">
                      <li className="flex items-start space-x-2">
                        <Check className="h-5 w-5 text-yellow-500 mt-0.5 flex-shrink-0" />
                        <span>Análisis detallado de márgenes por producto</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <Check className="h-5 w-5 text-yellow-500 mt-0.5 flex-shrink-0" />
                        <span>Optimización de costos operativos y logísticos</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <Check className="h-5 w-5 text-yellow-500 mt-0.5 flex-shrink-0" />
                        <span><strong>Looker Studio</strong></span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </div>

              <div className="mt-8 p-6 bg-blue-50 rounded-lg">
                <h3 className="text-xl font-bold text-blue-900 mb-4">Resultados Comprobados</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
                  <div>
                    <div className="text-3xl font-bold text-yellow-600">+25%</div>
                    <p className="text-muted-foreground">Mejora en rentabilidad promedio</p>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-yellow-600">-15%</div>
                    <p className="text-muted-foreground">Reducción en costos operativos</p>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-yellow-600">100%</div>
                    <p className="text-muted-foreground">Visibilidad en tiempo real</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Final Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-600 to-blue-800">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-white">
                  ¿Necesitás sumar a un especialista en eCommerce técnico y estratégico?
                </h2>
                <p className="max-w-[600px] text-blue-100 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed text-center mx-auto">
                  Contame sobre tu proyecto o equipo. Estoy listo para aportar valor con experiencia comprobada en
                  ventas digitales, catálogo técnico y operación MercadoLibre.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button size="lg" className="h-12 px-8 bg-yellow-500 hover:bg-yellow-600 text-black">
                  Enviar mensaje
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="h-12 px-8 border-white text-white hover:bg-white hover:text-blue-800 bg-transparent"
                >
                  Descargar CV
                </Button>
              </div>
              <div className="flex items-center space-x-4 text-sm text-blue-100">
                <div className="flex items-center space-x-1">
                  <Check className="h-4 w-4 text-yellow-400" />
                  <span> Respuesta rápida garantizada</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Check className="h-4 w-4 text-yellow-400" />
                  <span> Disponibilidad inmediata para entrevistas</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Check className="h-4 w-4 text-yellow-400" />
                  <span> Conocimiento técnico del rubro construcción y retail</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer id="contacto" className="w-full py-6 bg-gray-900 text-white">
        <div className="container px-4 md:px-6">
          <div className="grid gap-8 lg:grid-cols-4">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <img
                  src="/images/fp-logo.png"
                  alt="Francisco Peña Logo"
                  className="w-10 h-10 object-contain bg-white rounded-lg p-1"
                />
                <span className="text-xl font-bold">Francisco Pena</span>
              </div>
              <p className="text-sm text-gray-300">
                💻 Especialista en e-commerce. Más de 5 años optimizando catálogos, descripciones irresistibles y
                estrategias de venta online.
              </p>
              <p className="text-sm text-gray-300">
                Dominio total de fichas técnicas, SEO para productos y atención integral a clientes
              </p>
              <p className="text-sm text-gray-300">
                Desde el catálogo técnico hasta la entrega final: optimizo y mejoro todo el circuito en MercadoLibre.
              </p>

              <div className="flex space-x-4">
                <Link href="#" className="text-gray-300 hover:text-yellow-400">
                  <Linkedin className="h-5 w-5" />
                </Link>
                <Link href="#" className="text-gray-300 hover:text-yellow-400">
                  <Mail className="h-5 w-5" />
                </Link>
                <Link href="#" className="text-gray-300 hover:text-yellow-400">
                  <Phone className="h-5 w-5" />
                </Link>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-sm font-semibold">Resumen</h4>
              <div className="space-y-2">
                <Link href="#" className="text-sm text-gray-300 hover:text-yellow-400 block">
                  Habilidades
                </Link>
                <Link href="#" className="text-sm text-gray-300 hover:text-yellow-400 block">
                  Logística
                </Link>
                <Link href="#" className="text-sm text-gray-300 hover:text-yellow-400 block">
                  Experiencia personal
                </Link>
                <Link href="#" className="text-sm text-gray-300 hover:text-yellow-400 block">
                  eCommerce
                </Link>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-sm font-semibold">Navegación</h4>
              <div className="space-y-2">
                <Link href="#inicio" className="text-sm text-gray-300 hover:text-yellow-400 block">
                  Inicio
                </Link>
                <Link href="#perfil" className="text-sm text-gray-300 hover:text-yellow-400 block">
                  Perfil
                </Link>
                <Link href="#operacion-catalogo" className="text-sm text-gray-300 hover:text-yellow-400 block">
                  Operación & Catálogo
                </Link>
                <Link href="#analisis-automatizacion" className="text-sm text-gray-300 hover:text-yellow-400 block">
                  Análisis & Automatización
                </Link>
                <Link href="#contacto" className="text-sm text-gray-300 hover:text-yellow-400 block">
                  Contacto
                </Link>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-sm font-semibold">Contacto</h4>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Mail className="h-4 w-4 text-yellow-500" />
                  <span className="text-sm text-gray-300">franciscopena.ml@email.com</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4 text-yellow-500" />
                  <span className="text-sm text-gray-300">+54 1141871454</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Linkedin className="h-4 w-4 text-yellow-500" />
                  <span className="text-sm text-gray-300">linkedin.com/in/franciscopena</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-gray-700">
            <div className="flex flex-col sm:flex-row justify-between items-center">
              <p className="text-xs text-gray-300">
                © {new Date().getFullYear()} Francisco Peña. Todos los derechos reservados.
              </p>
              <div className="flex space-x-4 mt-4 sm:mt-0">
                <Link href="#" className="text-xs text-gray-300 hover:text-yellow-400">
                  Política de privacidad
                </Link>
                <Link href="#" className="text-xs text-gray-300 hover:text-yellow-400">
                  Términos de uso
                </Link>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
